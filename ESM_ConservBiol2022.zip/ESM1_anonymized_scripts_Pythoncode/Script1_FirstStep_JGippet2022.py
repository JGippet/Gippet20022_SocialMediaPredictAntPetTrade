# -*- coding: utf-8 -*-
"""
Created on Mon Jan 10 19:54:28 2022
@author: 
@purpose: Scrape a given hashtag on Instagram
"""



## PART 1: prepare directories and launch Instagram
import os
import undetected_chromedriver.v2 as uc


                                    ###################
                                    #### IMPORTANT ####
                                    ###################

# your Instagram session need to be open beforehand, so you are directly logged in when opening Instagram
# (if you decide to use your personal Instagram account, it is at your own risk of being banned by Facebook/meta) 
# I recommend using an anonymous account and internet proxies

                                    ###################
                                 
                                    
os.getcwd()
dir1 = 'C:/Users/cdarwin/Documents/ScrapingInstagram/URLs_lists' # basic work directory
hashtagScraped = "dontlookup" # change this variable for next hashtag

# opening chrome with selenium, with all your user info/cookies
options = uc.ChromeOptions()
options.user_data_dir = "C:/Users/cdarwin/AppData/Local/Google/Chrome/User Data"
options.add_argument('--no-first-run --no-service-autorun --password-store=basic')
driver = uc.Chrome(options=options)

# Now we go manually to the instagram # page we want to scrape

# Ready?



## PART 2: Semi-manual scraping of posts URLs (you scroll, Python copy/paste the URLs)
from ManualScroller import URLs_semimanual # you need to load this internal package

scrapeURLs = URLs_semimanual.UrlScraper(where=dir1)
scrapeURLs.extract_urls_by_hashtag_man(webpage=driver, hashtagScraped=hashtagScraped, saveDir=dir1)

# F9 to run the line
# Ctrl + C to stop the script, you can stop and re-run, just do not close Chrome 
# do not open any other Chrome window


## PART 3: Load and scrape the list of URLs obtained in part 2
import os
import requests
from bs4 import BeautifulSoup
import json
from datetime import datetime
import time
from random import choice, gauss, lognormvariate
import csv

# list of .csv files in folder (one csv per hashtag scraped for URLs)
listHT = os.listdir(dir1) 

## listing all URLs from, for example, 3 hashtags
rows = []
with open("{}/{}".format(dir1, listHT[0]),'r') as file:
    csvreader = csv.reader(file)
    header = next(csvreader)[0]
    for row in csvreader:
        rows.append(row[0])
        
with open("{}/{}".format(dir1, listHT[1]),'r') as file:
    csvreader = csv.reader(file)
    header = next(csvreader)[0]
    for row in csvreader:
        rows.append(row[0])
        
with open("{}/{}".format(dir1, listHT[2]),'r') as file:
    csvreader = csv.reader(file)
    header = next(csvreader)[0]
    for row in csvreader:
        rows.append(row[0])

len(rows) # but are duplicates 

## removing duplicates
list_uniquePosts = list(dict.fromkeys(rows))
len(list_uniquePosts) # list of unique URLs
#list_uniquePosts.insert(0, "uniqueHT") # add a column name


## Write the unique URLs in a csv file
wfile = open("{}/{}.csv".format(dir1, "uniqueHT"),'w')
wfile.write(",\n".join(list_uniquePosts))
wfile.close()

# scrapping directory
dir3 = 'C:/Users/cdarwin/Documents/ScrapingInstagram/unique_URLs' 
dir3

# create a dict indicating which URLs were successfully scrapped 
all_url_marked_INITIAL = dict.fromkeys([s.replace("\n", "") for s in list_uniquePosts], 'notVisitedYet')
# write the "all_url_marked_UPDATING" file. It will be updated during the scrapping process
#json.dump(all_url_marked_INITIAL, open("{}/{}.txt".format(dir3, 'all_url_marked_UPDATING'), 'w'))



      #
      ##
#########
##########  RESTART FROM HERE EACH TIME THE SCRIPT IS BLOCKED  #######
#########
      ##
      #
       
# Load the URL list with scraping status (ie, "notVisitedYet", "failed", "SCRAPED")
all_url_marked_UPDATING = json.load(open("{}/{}.txt".format(dir3, 'all_url_marked_UPDATING')))
len(all_url_marked_UPDATING)


# list only non already visited URL
all_url_NOTscrapedYET = [k for k, v in all_url_marked_UPDATING.items() if v== 'notVisitedYet']
len(all_url_NOTscrapedYET)

## list failed URLs: when Instagram starts to detect the scrapper, resquests fail
#all_url_FAILED = [k for k, v in all_url_marked_UPDATING.items() if v== 'failed']
#len(all_url_FAILED)


# create a list of waiting times to sample into
rd1 = [abs(lognormvariate(0.627, gauss(1.439,0.0253))) for i in range(5000)]
rd1 = [n for n in rd1 if (196.87>=n>=7.32)]
sum(rd1)/len(rd1) # average waiting between requests: 20 seconds

i=0
for url in all_url_NOTscrapedYET:
    i+=1
    print('Requesting url number {}: {}.'.format(i, url))
    # do the request
    try:
        pause1 = choice(rd1)
        print('We wait {} seconds and go to the next URL'.format(pause1))
        time.sleep(pause1)
        response = requests.get(url,  headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'})
        response.raise_for_status()
        
        # read and parse the html page obtain
        soup = BeautifulSoup(response.text, 'html.parser')
        body = soup.find('body')
        script_tag = body.find('script')
        raw_string = script_tag.string.strip().replace('window._sharedData =', '').replace(';', '')
        json_data = json.loads(raw_string)
        try:
            metrics = json_data['entry_data']['PostPage'][0]['graphql']['shortcode_media']
        except KeyError:
            all_url_marked_UPDATING[url] = 'failed'
            json.dump(all_url_marked_UPDATING, open("{}/{}.txt".format(dir3, 'all_url_marked_UPDATING'), 'w'))
            print('url {} failed.'.format(url))
            pass
        # write in text file
        date_post = str(datetime.fromtimestamp(metrics['taken_at_timestamp']))
        date_post = date_post.replace(' ', '_').replace(':', '-')
        wdir = os.path.join(os.getcwd(), 'unique_URLs', 'ScrapedPosts')
        with open("{}/{}.txt".format(wdir, ('UniqueList_' + date_post)), 'w', encoding='utf-8') as wfile:
            json.dump(metrics, wfile, ensure_ascii=False, indent=4)
        wfile.close()
        all_url_marked_UPDATING[url] = 'SCRAPED'
        json.dump(all_url_marked_UPDATING, open("{}/{}.txt".format(dir3, 'all_url_marked_UPDATING'), 'w'))
    except requests.HTTPError:
        all_url_marked_UPDATING[url] = 'failed'
        json.dump(all_url_marked_UPDATING, open("{}/{}.txt".format(dir3, 'all_url_marked_UPDATING'), 'w'))
        print('url {} failed. You were most likely spotted by Instagram... Try to change proxy'.format(url))
        pass
    except requests.RequestException as e:
        raise SystemExit(e)
    
    
# Instagram website structure and anti-scrapping algorithms evolve quickly.
# It means that this code might need to be updated in a few months...
# ... or will simply stop working a some point, and another strategy will be needed.





