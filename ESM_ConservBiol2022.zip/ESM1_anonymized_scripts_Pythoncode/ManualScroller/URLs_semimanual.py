# -*- coding: utf-8 -*-
"""
Created on Mon Jan 10 19:54:28 2022
@author: 
@purpose: Scrape the URLs of a given hashtag on Instagram
"""

import time
import os
from bs4 import BeautifulSoup
import shutil

class UrlScraper: 
    def __init__(self, where=os.getcwd()):
        self.where = where
        print("Ready to save URLs in {}.".format(os.path.abspath(where)))

    # method for getting URLs of a hashtags semi-manually
    def extract_urls_by_hashtag_man(self, webpage=None, hashtagScraped=None, saveDir=None, backupDir=None):
        self.webpage = webpage
        self.hashtagScraped = hashtagScraped
        self.saveDir = saveDir
        self.backupDir = backupDir
        if self.webpage is None:
            print('Please enter the webpage session object')
            raise SystemExit
        if self.hashtagScraped is None:
            print('Please enter the hashtag being scraped')
            raise SystemExit
        if self.saveDir is None:
            print('Please enter the directory path in which you want to save the scraped URLs .csv file')
            raise SystemExit
        if self.saveDir is None:
            print('Please enter the directory path in which you want to save a backup of the scraped URLs .csv file')
            raise SystemExit
            
        if os.path.isfile("{}/{}.csv".format(self.saveDir, self.hashtagScraped)):
            print('The file already exist, it will be updated... to interupt, press ctrl-C')
        else:
            wfile = open("{}/{}.csv".format(self.saveDir, self.hashtagScraped),'w')
            wfile.write(",\n".join([self.hashtagScraped+",\n"]))
            wfile.close()
        # a little pause before starting
        print('Wait for it (5 seconds) before starting to scroll')
        time.sleep(5)
        print('You can start scrolling ;)')
        while True:
            try:
                NBloop = 1
                links = []
                while NBloop <= 5:
                    time.sleep(abs(lognormvariate(1.2386395, gauss(0.1489,0.0125))))
                    soup_a = BeautifulSoup(self.webpage.page_source, 'lxml')
                    for link in soup_a.find_all('a'):
                        links.append(link.get('href'))
                    links_withoutDupli = list(dict.fromkeys(links))
                    links_withoutDupli_clean = [posturl for posturl in links_withoutDupli if ("/p/" in posturl)]
                    links_withoutDupli_clean = ["https://www.instagram.com" + x for x in links_withoutDupli_clean]      
                    print('Saving to the defined directory')
                    NBloop += 1
                wfile = open("{}/{}.csv".format(self.saveDir, self.hashtagScraped),'a', newline='\n')
                wfile.write(",\n".join(links_withoutDupli_clean) + ",\n")
                wfile.close()
                shutil.copyfile("{}/{}.csv".format(self.saveDir, self.hashtagScraped), "{}/{}.csv".format(self.backupDir, self.hashtagScraped)) # copy file to backup folder (a github local directory if possible)
            except KeyboardInterrupt:
                print('Stop for now')
                time.sleep(2)
                raise


