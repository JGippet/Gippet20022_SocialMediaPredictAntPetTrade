﻿#####################################################################################################################
##############################○○○○                                                 ○○○○##############################
##################○○○○                                                                         ○○○○##################
###########○○○○                                  Anonymous et al. - 2022                              ○○○○###########
###########○○○○        Social media data are reliable for monitoring emerging global pet trades       ○○○○###########
##################○○○○                                                                         ○○○○##################
##############################○○○○                                                 ○○○○##############################
#####################################################################################################################


# R version 4.0.2 (2020-06-22)

# load packages:
library(ade4)
library(ape)
library(babynames)
library(biomod2)
library(boot)
library(caret)
library(DHARMa)
library(dplyr)
library(eulerr)
library(extrafont)
library(forcats)
library(ggeffects)
library(ggExtra)
library(ggplot2)
library(ggpubr)
library(ggrepel)
library(ggside)
library(ggthemes)
library(ggtree)
library(glmmTMB)
library(gridExtra)
library(hrbrthemes)
library(knitr)
library(mapview)
library(MASS)
library(nngeo)
library(patchwork)
library(performance)
library(raster)
library(rasterVis)
library(RColorBrewer)
library(reshape2)
library(rgbif)
library(rnaturalearth)
library(rnaturalearthdata)
library(scales)
library(scico)
library(sf)
library(sjPlot)
library(tibble)
library(tidyr)
library(tidyverse)
library(tmap)
library(treeio)
library(viridis)


# color pallettes
fill_cols  <- alpha(c("#b2b2b2ff", "#c02e1dff", "#6eb1f4ff"), alpha= 1)


### some hanmade functions

# not in function
`%notin%` <- Negate(`%in%`)

# logit
logitj <- function(x) car::logit(x, adjust=0.000001)
inv_logitj <- function(x) boot::inv.logit(x) - 0.000001
my_new_transform <- trans_new(name = "logit_j",
                              transform = logitj,
                              inverse=inv_logitj)

# log of negatives
log_posNneg <- function(x){
  if (is.na(x)){v=NA}
  else{if (x<0){v = log(abs(x)+1)*(-1)}
    else {v = log(x+1)}
  }
  return(v)}

log_posNneg_vector  <- function(x){
  v= sapply(x, FUN=log_posNneg)
  return(v)
}

INV_log_posNneg <- function(x){
  if (is.na(x)){v=NA}
  else{
    if (x<0){v = (exp(abs(x))-1)*(-1)}
    else {v = exp(x)-1}
  }
  return(v)}

INV_log_posNneg_vector  <- function(x){
  v= sapply(x, FUN=INV_log_posNneg)
  return(v)
}


INV_log_posNneg_vector(log_posNneg_vector(c(-6,0,5,9,NA)))

log_neg_transform <- trans_new(name = "logneg_j",
                               transform = log_posNneg_vector,
                               inverse=INV_log_posNneg_vector)

# INV_log_posNneg_vector(log_posNneg_vector(c(5,-5, 0, NA)))


# manual R²

RSQUARE = function(y_actual,y_predict, nbVAR){
  Rsquared = cor(y_actual,y_predict)^2
  Adj_Rsquared = 1- ((1-Rsquared)*(length(y_actual)-1)/(length(y_actual)-nbVAR-1))
  return(list(Rsquared, Adj_Rsquared))
}




###################################################################################################################
####################################    >>>   PART 1  --  Geography   <<<    ##############################
###################################################################################################################

world1 <- ne_countries(scale = "medium", returnclass = "sf")
# Splitting multipartite polygons
world2 <- st_cast(world1,"POLYGON")

# calculating polygons area
c1 <- NULL
for (i in 1: dim(world2)[1]){
  c1 = c(c1, as.numeric(world2[i,] %>% 
                          st_transform(crs = "+proj=moll") %>% 
                          st_area()/1000000))
}

world2$area_sqkm <- c1
plot(world2["area_sqkm"])
length(world2)


## Ant sellers per country
ISusers <- read.table("./Datasets_Rcode/Anonymous2022_IS_byCountry.txt", sep="\t", h=T)
head(ISusers)

world2$ISusers <- NA
for (i in unique(ISusers$countryCode)){
  world2$ISusers[world2$iso_a2==i] <- ISusers$AntSellers[ISusers$countryCode==i]}

hist(world2$ISusers, nclass=20)
range(world2$ISusers, na.rm=T)


## total number of Instagram users per country (source: statista.com)
IGtrafficshare <- read.table("./Datasets_Rcode/Anonymous2022_Instagram_MillionUsersPerCountry_2020.txt", sep="\t", h=T)
head(IGtrafficshare)
IGtrafficshare$Million_Instagram_Users <- as.numeric(as.character(IGtrafficshare$Million_Instagram_Users))
range(IGtrafficshare$Million_Instagram_Users, na.rm=T)

# assigning value of 0.001 to country with no info
IGtrafficshare$Million_Instagram_Users[is.na(IGtrafficshare$Million_Instagram_Users)] <- 0.001

IGtrafficshare$iso2[is.na(IGtrafficshare$iso2)] <- "NA"

# feeding the info into the map object
world2$IGtrafficshare <- NA
for (i in unique(IGtrafficshare$iso3)){
  world2$IGtrafficshare[world2$iso_a3==i] <- IGtrafficshare$Million_Instagram_Users[IGtrafficshare$iso3==i]}


## Number of Instagram users referencing ant keeping per country
IGusers <- read.table("./Datasets_Rcode/Anonymous2022_IG_byCountry.txt", sep="\t", h=T)
head(IGusers)

# feeding the info into the map object
world2$IGusers <- NA
for (i in unique(IGusers$countryCode)){
  world2$IGusers[world2$iso_a2==i] <- IGusers$users[IGusers$countryCode==i]}

hist(world2$IGusers, nclass=20)
range(world2$IGusers, na.rm=T)



## plotting

tm1 <- tm_shape(world2, projection=st_crs('+proj=moll')) + #fill="grey95", col="grey75", 
  tm_polygons(col="ISusers", 
              style="log10",
              palette=c("#ededf7ff", "#9e9ed4ff", "#6565bbff", "#2d2d52ff"),
              breaks = log10(c(1,5,10,25)),
              colorNA="grey65",
              border.col = "grey5",
              lwd=1) +
  tm_layout(title = "", 
            frame=F,
            bg.color = "#f1fefcff", 
            earth.boundary=T,
            earth.boundary.color = "black",
            space.color = "white", 
            earth.boundary.lwd=1.5)
tm1 # number of ant sellers per country



tm3 <- tm_shape(world2, projection=st_crs('+proj=moll')) + #fill="grey95", col="grey75", 
  tm_polygons(col="IGusers", 
              style="log10",
              palette=c("#fbf9eaff", "#e7df8dff", "#d8cc46ff", "#6e6311ff"),
              breaks = log10(c(1,10,100, 250, 500)),
              colorNA="grey65",
              border.col = "grey5",
              lwd=1) +
  tm_layout(title = "", 
            frame=F,
            bg.color = "#f1fefcff", 
            earth.boundary=T,
            earth.boundary.color = "black",
            space.color = "white", 
            earth.boundary.lwd=1.5)
tm3 # number of Instagram users referencing ant-keeping per country



geo1 <- tmap_arrange(tm1, tm3)
#tmap_save(geo1, "fig2a_raw.pdf", width=6, height=8)


### Link?
dataset_geo <- data.frame(matrix(nrow=236, ncol = 4, dimnames= list(c(),c("country", "NbStores", "NbIGusers", "IGtrafficShare"))))
dataset_geo$country <- unique(world1$iso_a2)
dataset_geo$NbStores <- 0
dataset_geo$NbIGusers <- 0
dataset_geo$Million_Instagram_Users <- 0
dataset_geo$population <- 0

for (i in unique(ISusers$countryCode)){
  dataset_geo$NbStores[dataset_geo$country==i] <- ISusers$AntSellers[ISusers$countryCode==i]
}

for (i in unique(IGusers$countryCode)){
  dataset_geo$NbIGusers[dataset_geo$country==i] <- IGusers$users[IGusers$countryCode==i]
}

for (i in unique(IGtrafficshare$iso2)){
  dataset_geo$Million_Instagram_Users[dataset_geo$country==i] <- IGtrafficshare$Million_Instagram_Users[IGtrafficshare$iso2==i]
}

for (i in unique(dataset_geo$country)){
  if(length(world1$pop_est[world1$iso_a2==i][!is.na(world1$pop_est[world1$iso_a2==i])])>0){
    dataset_geo$population[dataset_geo$country==i] <- world1$pop_est[world1$iso_a2==i][!is.na(world1$pop_est[world1$iso_a2==i])]
  }
}


dim(dataset_geo)
head(dataset_geo)
sum(dataset_geo$NbIGusers)

hist(dataset_geo$Million_Instagram_Users)
range(dataset_geo$Million_Instagram_Users)

# log-transformed variables of interest
dataset_geo$NbStores_log <- log(dataset_geo$NbStores+1)
dataset_geo$NbIGusers_log <- log(dataset_geo$NbIGusers+1)
dataset_geo$Million_Instagram_Users_log <- log((dataset_geo$Million_Instagram_Users*1000000)+1)
dataset_geo$Million_Instagram_Users_trafficShare <- car::logit(dataset_geo$Million_Instagram_Users/(sum(dataset_geo$Million_Instagram_Users)))

# world population
dataset_geo$population_log <- log(dataset_geo$population+1)


plot(NbStores_log ~ NbIGusers_log, data=dataset_geo)
plot(NbStores_log ~ Million_Instagram_Users_log, data=dataset_geo)
plot(NbStores_log ~ population_log, data=dataset_geo)

# models 
lm_geo <- glm.nb(NbStores ~ 1
                 + NbIGusers_log
                 #+ Million_Instagram_Users_log
                 ,
                 data=dataset_geo)
summary(lm_geo)
plot(simulateResiduals(lm_geo))
r2(lm_geo)


ef_lm_geo <- ggpredict(lm_geo, c("NbIGusers_log"), back.transform=TRUE, type="fe") # , condition = list(NbAllSpecies_log =2)
plot(ef_lm_geo, line.size=1.75, dot.size=4, dodge=0.4) 


fig_lm_geo <- ggplot(data=dataset_geo, 
                     aes(x=NbIGusers_log, 
                         y=NbStores+2)) + # the '+2' is for plotting purpose (limit space between 0 and 1 when logging y)
  geom_line(data=ef_lm_geo, 
            aes(x=x, y=predicted+2), 
            size=1.25, 
            col='black') +
  geom_ribbon(data = ef_lm_geo, 
              aes(ymin = conf.low+2, 
                  ymax = conf.high+2, 
                  x = x),
              fill = 'grey5', alpha = 0.3, inherit.aes = FALSE) +
  geom_jitter(data= dataset_geo,
              aes(size=Million_Instagram_Users_trafficShare, 
                  fill=Million_Instagram_Users_trafficShare),
              shape=21,
              color="black",
              height=0.075,
              width=0.075) +
  scale_size_continuous(range = c(2, 12),
                        breaks=car::logit(c(0, 1, 2.5, 5, 10)),
                        labels=c("<0.1%", "1%", "2.5%", "5%", "10%")) +
  scale_fill_viridis(option= "viridis",
                     alpha=0.7,
                     direction=-1,
                     breaks=car::logit(c(0, 1, 2.5, 5, 10)),
                     labels=c("<0.1%", "1%", "2.5%", "5%", "10%")) +
  scale_y_continuous(name="Number of sellers by country",
                     breaks=c(0, 1, 2, 5, 10, 20, 50, 100)+2,
                     labels=c(0, 1, 2, 5, 10, 20, 50, 100),
                     trans='log') +
  scale_x_continuous(name="Number of Instagram users",
                     breaks=log(c(0, 1, 2, 5, 10, 20, 50, 100, 200, 500)+1),
                     labels=c(0, 1, 2, 5, 10, 20, 50, 100, 200, 500)) +
  labs(size='Instagram traffic share', fill='Instagram traffic share') +
  theme_bw() +
  theme(plot.margin = unit(c(1, 1, 1, 1), "cm"),
        #text=element_text(size=16,  family="Segoe UI"),
        axis.title.x = element_text(size = 15, vjust = -2),
        axis.title.y = element_text(size = 15, vjust = 2),
        axis.text.x = element_text(size=14),
        axis.text.y = element_text(size=14),
        legend.title = element_text(size=8, color = "black", face="bold"),
        legend.justification=c(0,1), 
        #legend.position=c(0.05, 0.95),
        legend.background = element_blank(),
        legend.key = element_blank(),
        panel.grid.minor.x = element_blank(),
        panel.grid.minor.y = element_blank(),
        panel.grid.major.x = element_line(size=.2, linetype=2, color="grey85" ),
        panel.grid.major.y = element_line(size=.2, linetype=2, color="grey85" )) 
#+ geom_text(aes(label=country))

fig_lm_geo
#ggsave("fig2b_raw.pdf", fig_lm_geo, width=6.5, height=4.75)



#########################################################################################################
#########################################################################################################



###################################################################################################################
####################################   >>>  PART 2  --  Taxonomic composition  <<<   ##############################
###################################################################################################################

################################################
############### LOAD DATASETS  #################
################################################
list.files()

# List of all ant species with information on trade (number of sellers and price for 2017 and 2020 surveys)
GSP_ants <- read.table("./Datasets_Rcode/Anonymous2022_AntTrade_2020.txt", h=T)
GSP_ants$InvasivenessStatus <- factor(GSP_ants$InvasivenessStatus, levels=c("Native","Alien","Invasive"))
head(GSP_ants)
dim(GSP_ants)
GSP_ants[GSP_ants$species=="Lasius_niger",]

# Chronogram
Phylotree_ants <- read.tree("./Datasets_Rcode/Anonymous2022_Phylotree_ants_2020.nwk") # from timetree.org, accessed ? 2020
Phylotree_ants

# Data Instagram
Instagram_ants <- read.csv("./Datasets_Rcode/Anonymous2022_IGstats_antspecies_v2022.2.csv", sep=";", h=T)
head(Instagram_ants)
dim(Instagram_ants)

row.names(Instagram_ants) <- Instagram_ants$Species

### adding up some information
    # invasiveness status
    for (i in 1: dim(Instagram_ants)[1]){
      Instagram_ants$status[i] <- as.character(GSP_ants$InvasivenessStatus[which(GSP_ants$species==row.names(Instagram_ants)[i])])
      Instagram_ants$sub.family[i] <- as.character(GSP_ants$sub.family[which(GSP_ants$species==row.names(Instagram_ants)[i])])
      Instagram_ants$genus[i] <- as.character(GSP_ants$genus[which(GSP_ants$species==row.names(Instagram_ants)[i])])
    }
    Instagram_ants$status <- as.factor(Instagram_ants$status)
    Instagram_ants$status = factor(Instagram_ants$status, levels=c("Native","Alien","Invasive"))
    Instagram_ants$PostsByUser <- Instagram_ants$NbPosts_total/Instagram_ants$NbUsers_total 
    head(Instagram_ants)
    

    # cumulative number of active users and of posts in 2020
    Instagram_ants$nbUsers_2020_cum <- rowSums(Instagram_ants[,c("nbUsers_2012", 
                                                                 "nbUsers_2013", 
                                                                 "nbUsers_2014", 
                                                                 "nbUsers_2015", 
                                                                 "nbUsers_2016", 
                                                                 "nbUsers_2017", 
                                                                 "nbUsers_2018", 
                                                                 "nbUsers_2019", 
                                                                 "nbUsers_2020")])
    
    Instagram_ants$nbPosts_2020_cum <- rowSums(Instagram_ants[,c("nbPosts_2012", 
                                                                 "nbPosts_2013", 
                                                                 "nbPosts_2014", 
                                                                 "nbPosts_2015", 
                                                                 "nbPosts_2016", 
                                                                 "nbPosts_2017", 
                                                                 "nbPosts_2018", 
                                                                 "nbPosts_2019", 
                                                                 "nbPosts_2020")])
head(Instagram_ants)

###########################################################
###########################################################


    
###########################################################
############### INSTAGRAM data over time  #################
###########################################################

df2 <- Instagram_ants
head(df2)
dim(df2)
colnames(df2)

# computing cumulative sum of posts by species 
df3.posts <- df2[,c("nbPosts_2012",
                    "nbPosts_2013",
                    "nbPosts_2014", 
                    "nbPosts_2015", 
                    "nbPosts_2016", 
                    "nbPosts_2017", 
                    "nbPosts_2018", 
                    "nbPosts_2019", 
                    "nbPosts_2020")]
head(df3.posts)

# cumulating
for (i in 2:9){
  df3.posts[,i] = df3.posts[,i-1]+ df3.posts[,i]
}
head(df3.posts)

# computing cumulative sum of active users by species 
df3.users <- df2[,c("nbUsers_2012",
                    "nbUsers_2013",
                    "nbUsers_2014", 
                    "nbUsers_2015", 
                    "nbUsers_2016", 
                    "nbUsers_2017", 
                    "nbUsers_2018", 
                    "nbUsers_2019", 
                    "nbUsers_2020")]
# cumulating
for (i in 2:9){
  df3.users[,i] = df3.users[,i-1]+ df3.users[,i]
}
head(df3.users)


## ok
df3 <- cbind(df3.posts, df3.users, df2$NbUsers_total, df2$sub.family, df2$genus, df2$status)
colnames(df3) <- c(colnames(df3.posts), colnames(df3.users), "NbUsers_total", "sub.family", "genus", "status")
head(df3)

minimum <-0


# data with number of posts
head(df3)

df6 <- df3[df3$NbUsers_total>minimum, c(1:9)]
df6$species <- row.names(df6)
colnames(df6) <- c(2012:2020, "species")
head(df6)
dim(df6)

df6.1 <- melt(df6,id.vars=c("species"), value.name="nbPosts",
              variable.name="year")
head(df6.1)
dim(df6.1)
df6.1$NbUsers_total <- rep(df3$NbUsers_total,9)
df6.1$NbPosts_total <- rep(df3$nbPosts_2020,9)
df6.1$plotorder <- rep(factor(paste0(rank(df6$'2020'), df6$species)),9)
df6.1$year <- as.numeric(as.character(df6.1$year))

df6.1[df6.1$species=="Lasius_niger",]
df6.1[df6.1$species=="Messor_barbarus",]

# cum sum by year
df6.1_total <- aggregate(nbPosts ~ year, data=df6.1, FUN=sum)

# How many new species appear on Instagram each year?
df6.1_new_species <- df6.1_total
colnames(df6.1_new_species)[2] <- "NbNewSpecies"
df6.1_new_species$NbNewSpecies <- 0

temp3 <- df6$species[df6$'2012'>0]
df6.1_new_species$NbNewSpecies[df6.1_new_species$year==2012] <- length(temp3)
temp4 <- df6$species[df6$'2013'>0][df6$species[df6$'2013'>0] %notin% unique(c(temp3))]
df6.1_new_species$NbNewSpecies[df6.1_new_species$year==2013] <- length(temp4)
temp5 <- df6$species[df6$'2014'>0][df6$species[df6$'2014'>0] %notin% unique(c(temp3, temp4))]
df6.1_new_species$NbNewSpecies[df6.1_new_species$year==2014] <- length(temp5)
temp6 <- df6$species[df6$'2015'>0][df6$species[df6$'2015'>0] %notin% unique(c(temp3, temp4, temp5))]
df6.1_new_species$NbNewSpecies[df6.1_new_species$year==2015] <- length(temp6)
temp7 <- df6$species[df6$'2016'>0][df6$species[df6$'2016'>0] %notin% unique(c(temp3, temp4, temp5, temp6))]
df6.1_new_species$NbNewSpecies[df6.1_new_species$year==2016] <- length(temp7)
temp8 <- df6$species[df6$'2017'>0][df6$species[df6$'2017'>0] %notin% unique(c(temp3, temp4, temp5, temp6, temp7))]
df6.1_new_species$NbNewSpecies[df6.1_new_species$year==2017] <- length(temp8)
temp9 <- df6$species[df6$'2018'>0][df6$species[df6$'2018'>0] %notin% unique(c(temp3, temp4, temp5, temp6, temp7, temp8))]
df6.1_new_species$NbNewSpecies[df6.1_new_species$year==2018] <- length(temp9)
temp10 <- df6$species[df6$'2019'>0][df6$species[df6$'2019'>0] %notin% unique(c(temp3, temp4, temp5, temp6, temp7, temp8, temp9))]
df6.1_new_species$NbNewSpecies[df6.1_new_species$year==2019] <- length(temp10)
temp11 <- df6$species[df6$'2020'>0][df6$species[df6$'2020'>0] %notin% unique(c(temp3, temp4, temp5, temp6, temp7, temp8, temp9, temp10))]
df6.1_new_species$NbNewSpecies[df6.1_new_species$year==2020] <- length(temp11)

df6.1_new_species


# data with number of active users
head(df3)

df7 <- df3[df3$NbUsers_total>minimum, c(10:18)]
df7$species <- row.names(df7)
colnames(df7) <- c(2012:2020, "species")
head(df7)
dim(df7)

df7.1 <- melt(df7,id.vars=c("species"), value.name="nbUsers",
              variable.name="year")
head(df7.1)
dim(df7.1)
df7.1$NbUsers_total <- rep(df3$NbUsers_total,9)
df7.1$NbPosts_total <- rep(df3$nbPosts_2020,9)
df7.1$plotorder <- rep(factor(paste0(rank(df7$'2020'), df7$species)),9)
df7.1$year <- as.numeric(as.character(df7.1$year))

df7.1[df7.1$species=="Lasius_niger",]
df7.1[df7.1$species=="Messor_barbarus",]

# cum sum by year
df7.1_total <- aggregate(nbUsers ~ year, data=df7.1, FUN=sum)


## plotting all these informayion

# main plot: number of posts per species per year
nbPosts_plot <- ggplot(data=df6.1,aes(x=year, 
                                      y=nbPosts+1,
                                      group=plotorder)) +
  geom_hline(yintercept=c(0,10, 100, 1000,10000)+1,
             color="grey5",
             linetype="dotted",
             alpha=0.2,
             size=0.25) +
  geom_line(size=0.5,
            aes(color=log(NbUsers_total+1))) +
  labs(y= "Number of posts", x = "Year", color='Nmber of users in 2020') +
  geom_point(size=0.5, 
             color="darkred") +
  scale_y_continuous(limits=c(1,20000), 
                     breaks= c(0, 10, 100, 1000, 10000)+1,
                     labels= c(0, 10, 100, 1000,10000),
                     trans = "log") +
  scale_x_continuous(limits=c(2012,2020),
                     breaks=c(2012:2020)) +
  scale_color_viridis(direction=-1, 
                      option="mako", 
                      alpha=0.75,
                      breaks = log(c(5,20,100,500)+1), 
                      labels=c(5,20,100,500)) +
  theme_pubr() +
  theme(plot.margin = unit(c(0,0,0,0), 'mm'),
        legend.key.size = unit(0.5, 'cm'),
        legend.position = c(0.25, 0.79),
        legend.direction = 'horizontal',
        legend.text=element_text(size=8),
        legend.title = element_text(size=8),
        axis.title.x=element_text(size=10),
        axis.title.y=element_text(size=12),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10)) +
  guides(colour = guide_colourbar(title.position="top", title.hjust = 0.5),
         size = guide_legend(title.position="top", title.hjust = 0.5)) +
  geom_line(data= df6.1_total,
            aes(x=year, 
                y=nbPosts+1,
                group=1),
            color="indianred",
            size=1,
            linetype=6)
#annotate("text", x=2018, y=1300, size=3, fontface = 'italic', label= "Lasius niger")

# right panel: distribution of the number of posts per species in 2020
NbPosts_dens <- ggplot(df6.1[df6.1$year==2020,], aes(x= log(nbPosts+1))) + 
  geom_vline(xintercept=log(c(0,10, 100, 1000,10000)+1),
             color="grey5",
             linetype="dotted",
             alpha=0.2,
             size=0.25) +
  geom_density(alpha=0.75,
               col="black",
               fill="indianred") +
  #ggtitle("Number of posts per species in 2019") +
  scale_fill_manual(values=viridis(2)) +
  scale_y_continuous(position = "right",
                     name="Frequency",
                     limits=c(0,0.5),
                     breaks = c(0,0.25,0.5)) +
  scale_x_continuous(position = "top",
                     name="Number of posts per species in 2020",
                     limits=log(c(1,20001)), 
                     breaks= log(c(0,10, 100, 1000,10000)+1),
                     labels= c(0,10, 100, 1000,10000)) +
  theme_pubr() +
  theme(plot.margin = unit(c(0,0,0,0), 'mm'),
        axis.title.x=element_text(size=8),
        axis.title.y=element_text(size=12),
        axis.text.x = element_text(size=6),
        axis.text.y = element_text(size=8)) +
  coord_flip()


#
df6.1_new_species

bar_plot <- ggplot(data=df6.1_new_species, aes(x=year, 
                                               y=NbNewSpecies, 
                                               fill=NbNewSpecies,
                                               label=NbNewSpecies)) +
  geom_hline(yintercept=c(0,100, 200,300),
             color="grey5",
             linetype="dotted",
             alpha=0.2,
             size=0.25) +
  geom_bar(stat="identity", width=0.85) +
  coord_cartesian(xlim= c(2012,2020)) +
  scale_x_continuous(breaks=c(2012:2020)) +
  scale_y_continuous(limits=c(0,300),
                     name=expression(paste("Number of new\n     species"))) +
  scale_fill_viridis(direction=-1, 
                     option="rocket", 
                     alpha=1) +
  geom_text(aes(fontface=2),
            size=3,
            vjust=-0.5)+
  theme_pubr() +
  theme(plot.margin = unit(c(0,0,0,0), 'mm'),
        legend.position = "none",
        # legend.direction = 'horizontal',
        # legend.text=element_text(size=8),
        # legend.title = element_text(size=10),
        axis.title.x=element_blank(),
        axis.title.y=element_text(size=10, margin = margin(t = 0, r = -15, b = 0, l = 0)),
        axis.text.x = element_text(size=8),
        axis.text.y = element_text(size=8)) 


# combining the plots
fig3 <- bar_plot + plot_spacer() + nbPosts_plot + NbPosts_dens + 
  plot_layout(ncol = 2, nrow = 2, widths = c(5, 1), heights=c(1,5))

fig3
# ggsave("fig_nbPosts.pdf", fig3, width=6, height=5)
# ggsave("fig_nbPosts.png", fig3, width=6, height=5)

####################################


###########################################################
###########################################################



###########################################################
############# SUB-FAMILY level  composition  ##############
###########################################################

GSP_ants_v2 <- GSP_ants
## >> building a contingency table of subfamilies in global pool, traded ants and insta ants << ##
Subfamilies <- data.frame(sort(table(GSP_ants_v2$sub.family), decreasing = T))
colnames(Subfamilies) <- c("sub.family", "nb.species")
# traded species
Subfamilies$nb.traded.species = 0
traded.subfam <- table(GSP_ants_v2$sub.family[GSP_ants_v2$Traded2020==1])
for (sf in names(traded.subfam)){
  Subfamilies$nb.traded.species[Subfamilies$sub.family==sf] <- traded.subfam[sf]}
# instagram species
Subfamilies$nb.instagram.species = 0
instagram.subfam <- table(Instagram_ants$sub.family)
for (sf in names(instagram.subfam)){
  Subfamilies$nb.instagram.species[Subfamilies$sub.family==sf] <- instagram.subfam[sf]}

Subfamilies <- Subfamilies[order(Subfamilies$nb.species, Subfamilies$nb.traded.species, Subfamilies$nb.instagram.species, decreasing=T ) ,]

# Axis treated as discrete variable
tabSF <- data.frame(SF=rep(Subfamilies$sub.family, each=3),
                    group=rep(c("Total", "Traded", "Instagram"),18))
tabSF$nb.species = 0
tabSF$nb.species[tabSF$group=="Total"] <- Subfamilies$nb.species
tabSF$nb.species[tabSF$group=="Traded"] <- Subfamilies$nb.traded.species
tabSF$nb.species[tabSF$group=="Instagram"] <- Subfamilies$nb.instagram.species

tabSF$prop.species = 0
tabSF$prop.species[tabSF$group=="Total"] <- Subfamilies$nb.species/sum(Subfamilies$nb.species)
tabSF$prop.species[tabSF$group=="Traded"] <- Subfamilies$nb.traded.species/sum(Subfamilies$nb.traded.species)
tabSF$prop.species[tabSF$group=="Instagram"] <- Subfamilies$nb.instagram.species/sum(Subfamilies$nb.instagram.species)
# tabSF <- tabSF[c(1:24,35,36),]

tabSF$group <- as.factor(tabSF$group)
tabSF$group = factor(tabSF$group,levels(tabSF$group)[c(2,3,1)])
levels(tabSF$group)

levels(tabSF$SF)
tabSF$SF <- factor(tabSF$SF, levels = as.character(unique(tabSF$SF)))
tabSF <- tabSF[1:30,] # only the 10 main subfamilies

fig4a <-  ggplot(data=tabSF, aes(x=fct_rev(fct_infreq(SF)), y=prop.species, fill=fct_rev(fct_infreq(group)))) +
  geom_bar(stat="identity", color="black", position=position_dodge(), size=0.5, width=0.85) +
  theme_classic() +
  coord_flip() +
  theme(axis.title=element_text(size=12,face="bold"), 
        axis.text.x = element_text( face="bold", size=10), 
        axis.text.y = element_text( face="bold", size=10),
        legend.position=c(0.75,0.2),
        plot.margin=unit(c(1,1,1,1),"cm"),
        axis.title.x = element_text(margin = margin(t = 10)),
        axis.title.y = element_text(margin = margin(r = 20))) +
  labs(title = "", 
       subtitle = NULL, 
       caption = NULL, 
       tag = "Figure 1", 
       y = "Proportion of species",
       x = "Sub-families",
       colour = "Gears") +
  scale_fill_manual(name="Group", 
                    labels=rev(c("All ant species (N=15,377)","Traded species (N=520)",  "Instagram species (N=714)")), 
                    values=rev(c('#d0d0d0ff','#7b7bc5ff', '#dfd05bff')))

fig4a

# pdf("fig4a_raw.pdf", height = 10, width = 7)
# print(fig4a)
# dev.off()



# proportion test
groupe1= 'Myrmicinae'
groupe2= 'Formicinae'
groupe3= 'Ponerinae'
groupe4= 'Dolichoderinae'
groupe5= 'Dorylinae'
groupe6= 'Ectatomminae'
groupe7= 'Pseudomyrmecinae'
groupe8= 'Proceratiinae'
groupe9= 'Amblyoponinae'
groupe10= 'Myrmeciinae'

groupe = groupe1
instagram_group = c(tabSF$nb.species[tabSF$SF==groupe & tabSF$group=="Instagram"], sum(tabSF$nb.species[tabSF$group=="Instagram"]))
traded_group = c(tabSF$nb.species[tabSF$SF==groupe & tabSF$group=="Traded"], sum(tabSF$nb.species[tabSF$group=="Traded"]))
total = c(tabSF$nb.species[tabSF$SF==groupe & tabSF$group=="Total"]/sum(tabSF$nb.species[tabSF$group=="Total"]), 1-tabSF$nb.species[tabSF$SF==groupe & tabSF$group=="Total"]/sum(tabSF$nb.species[tabSF$group=="Total"]) )

prop_trade <- chisq.test(traded_group, p = total) # test if same proportion than in global species pool
prop_instagram <- chisq.test(instagram_group, p = total) # test if same proportion than in global species pool

# Bonferroni correction for multiple tests
prop_trade$p.value*20
prop_instagram$p.value*20




###########################################################
###########################################################



###########################################################
#############    GENUS level  composition    ##############
###########################################################

head(GSP_ants_v2)

dfIS <- GSP_ants_v2[(GSP_ants_v2$Traded2020==1), c("sub.family",
                                                   "genus",
                                                   "NbSellers_2020",
                                                   "MeanPrice_2020",
                                                   "InvasivenessStatus")]
row.names(dfIS) <- GSP_ants_v2$species[(GSP_ants_v2$Traded2020==1)]
head(dfIS)
dim(dfIS)

table(dfIS$NbSellers_2020)

head(Instagram_ants)
dfIG <- Instagram_ants
head(dfIG)
dim(dfIG)


# building a circular phylogenetic tree and coloring branches based on commercial, sm variables
# https://yulab-smu.github.io/treedata-book/chapter4.html
# https://bioconductor.statistik.tu-dortmund.de/packages/3.1/bioc/vignettes/ggtree/inst/doc/ggtree.html
# https://yulab-smu.github.io/treedata-book/faq.html


Phylotree_ants
tree_ants <- Phylotree_ants

toRM <- c()
for (genus in tree_ants$tip.label){ 
  if(genus %in% GSP_ants_v2$genus){
  } else {toRM <-c(toRM, genus)}
} 

# Deleting genus not in dataset (Pyramica, Oligomyrmex, Phasmomyrmex...)
for (i in 1:length(Phylotree_ants$tip.label) ) {
  print(paste("doing",i))
  tree_ants <- drop.tip(tree_ants, toRM,trim.internal=TRUE) 
}

genera <- tree_ants$tip.label
allAntsGenera <- table(GSP_ants_v2$genus)

# put all in a df
dfAntsParam <- as.data.frame( matrix(data=NA, ncol=19, nrow=length(genera)))
colnames(dfAntsParam) = c( 'Nbspecies_IS', 'Nbspecies_IG', 'Propspecies_IS', 'Propspecies_IG', 
                           'SumNbS', 'MeanNbS', 'SeNbS', 
                           'MeanPrice', 'SePrice', 
                           'SumIGusers', 'MeanIGusers',
                           'SumNbPosts', 'MeanNbPosts',
                           'SumIGlikes', 'MedianIGlikes',
                           'SumIGcomments', 'MedianIGcomments',
                           'sub.family', 'NbAllSpecies')
row.names(dfAntsParam) = genera

head(dfAntsParam)
dim(GSP_ants_v2)
sort(GSP_ants_v2$genus)


for (genus in genera){
  print(genus)
  dfAntsParam[genus, 'sub.family'] = unique(GSP_ants_v2$sub.family[GSP_ants_v2$genus==genus])
  dfAntsParam[genus, 'NbAllSpecies'] = dim(GSP_ants[GSP_ants_v2$genus==genus,])[1]
  
  dfAntsParam[genus, 'Nbspecies_IS'] = 0
  dfAntsParam[genus, 'Nbspecies_IG'] = 0
  
  dfAntsParam[genus, 'Propspecies_IS'] = 0
  dfAntsParam[genus, 'Propspecies_IG'] = 0
  
  if (genus %in% dfIS$genus){
    df1 <- dfIS[dfIS$genus==genus,]
    
    dfAntsParam[genus, 'Nbspecies_IS'] = length(unique(row.names(df1)))
    dfAntsParam[genus, 'Propspecies_IS'] = length(unique(row.names(df1)))/allAntsGenera[names(allAntsGenera)==genus]
    
    dfAntsParam[genus, 'SumNbS'] = sum(df1$NbSellers_2020, na.rm=T)
    dfAntsParam[genus, 'MeanNbS'] = mean(df1$NbSellers_2020, na.rm=T)
    dfAntsParam[genus, 'SeNbS'] = sqrt(var(df1$NbSellers_2020, na.rm=T)/length(which(!is.na(df1$NbSellers))))
    
    dfAntsParam[genus, 'MeanPrice'] = mean(df1$MeanPrice_2020, na.rm=T)
    dfAntsParam[genus, 'SePrice'] = sqrt(var(df1$MeanPrice_2020, na.rm=T)/length(which(!is.na(df1$MeanPrice))))
  }
  if (genus %in% dfIG$genus){
    df2 <- dfIG[dfIG$genus==genus,]
    dfAntsParam[genus, 'Nbspecies_IG'] = length(unique(row.names(df2)))
    dfAntsParam[genus, 'Propspecies_IG'] = length(unique(row.names(df2)))/allAntsGenera[names(allAntsGenera)==genus]
    
    dfAntsParam[genus, 'SumIGusers'] = sum(df2$NbUsers_total, na.rm=T)
    dfAntsParam[genus, 'MeanIGusers'] = mean(df2$NbUsers_total, na.rm=T)
    
    dfAntsParam[genus, 'SumNbPosts'] = sum(df2$NbPosts_total, na.rm=T)
    dfAntsParam[genus, 'MeanNbPosts'] = mean(df2$NbPosts_total, na.rm=T)
    #dfAntsParam[genus, 'SeIGusers'] = sqrt(var(df2$byUser, na.rm=T)/length(df2$byUser))
    
    dfAntsParam[genus, 'SumIGlikes'] = sum(df2$medianLikes, na.rm=T)
    dfAntsParam[genus, 'MedianIGlikes'] = mean(df2$medianLikes, na.rm=T)
    # if(is.na(var(df2$medianLikes))){
    # }else{dfAntsParam[genus, 'SeIGlikes'] = sqrt(var(df2$medianLikes,na.rm=T)/length(which(!is.na(df2$medianLikes))))}
    
    dfAntsParam[genus, 'SumIGcomments'] = sum(df2$medianComments, na.rm=T)
    dfAntsParam[genus, 'MedianIGcomments'] = mean(df2$medianComments, na.rm=T)
    # if(is.na(var(df2$medianComments))){
    # }else{dfAntsParam[genus, 'SeIGcomments'] = sqrt(var(df2$medianComments,na.rm=T)/length(which(!is.na(df2$medianComments))))}
    # dfAntsParam[genus, 'MedianIGlikes'] = mean(log(df2$medianLikes+1), na.rm=T)
    # dfAntsParam[genus, 'SeIGlikes'] = sqrt(var(log(df2$medianLikes+1), na.rm=T)/length(df2$medianLikes))
  }
}


dfAntsParam$SumNbS[is.na(dfAntsParam$SumNbS)] <- 0
dfAntsParam$MeanNbS[is.na(dfAntsParam$MeanNbS)] <- 0
dfAntsParam$SumIGusers[is.na(dfAntsParam$SumIGusers)] <- 0
dfAntsParam$MeanIGusers[is.na(dfAntsParam$MeanIGusers)] <- 0
dfAntsParam$SumNbPosts[is.na(dfAntsParam$SumNbPosts)] <- 0
dfAntsParam$MeanNbPosts[is.na(dfAntsParam$MeanNbPosts)] <- 0

head(dfAntsParam)
dim(dfAntsParam)


### Representing commercial and popularity indices on the ant genus tree ###
#dfAntsParam_v2 <- dfAntsParam[,c(1,2,3,4,5,6,8,9,10,11,13,14,15,16)]
dfAntsParam_v2 <- dfAntsParam
head(dfAntsParam_v2)
dfAntsParam_v2$Propspecies_IS <- car::logit(dfAntsParam_v2$Propspecies_IS, adjust=0.001)
dfAntsParam_v2$Propspecies_IG <- car::logit(dfAntsParam_v2$Propspecies_IG, adjust=0.001)
dim(dfAntsParam_v2)

##
dfAntsParam_v3 <- dfAntsParam_v2[(dfAntsParam_v2$Nbspecies_IS!=0 & dfAntsParam_v2$Propspecies_IG!=min(dfAntsParam_v2$Propspecies_IG)) | dfAntsParam_v2$Nbspecies_IS==0 & dfAntsParam_v2$Propspecies_IG==min(dfAntsParam_v2$Propspecies_IG),]
dfAntsParam_v3 <- dfAntsParam_v2[dfAntsParam_v2$Propspecies_IG!=min(dfAntsParam_v2$Propspecies_IG),]
dfAntsParam_v3 <- dfAntsParam_v2
head(dfAntsParam_v3)
dim(dfAntsParam_v3)

sort(dfAntsParam_v3$SumIGusers)

hist(dfAntsParam_v3$Propspecies_IS)
plot(Propspecies_IS ~ Propspecies_IG, data=dfAntsParam_v3)
dfAntsParam_v3$Propspecies_IS_raw <- dfAntsParam_v3$Nbspecies_IS / dfAntsParam_v3$NbAllSpecies

lm1 = glmmTMB(cbind(Nbspecies_IS, NbAllSpecies) ~ 1 +
                Propspecies_IG +
                (1|sub.family),
              data = dfAntsParam_v3, 
              family = binomial)

summary(lm1)
r2(lm1)
plot(simulateResiduals(lm1))


lm1_p <- ggemmeans(lm1, c("Propspecies_IG[all]"), type="fe") 
plot(lm1_p, line.size=1.75, dot.size=4, dodge=0.4) 

dfAntsParam_v3.2 <- dfAntsParam_v3

fig4d <- ggplot(data=dfAntsParam_v3.2, aes(x=(Propspecies_IG), y=(Propspecies_IS))) +
  theme_classic() +
  theme(plot.margin = unit(c(2, 2, 1, 1), "cm"),
        axis.title.x = element_text(size = 15, vjust = -2),
        axis.title.y = element_text(size = 15, vjust = 2),
        axis.text.x = element_text(size=14),
        axis.text.y = element_text(size=14)) +
  geom_point(size=log(dfAntsParam_v3.2$NbAllSpecies+1)*3,
             alpha=0.2,
             shape = 21,
             colour = "black",
             fill = 'grey65',
             stroke = 0.5) +
  geom_line(data=lm1_p, 
            aes(x=(x), y=car::logit(predicted, adjust=0.001)), 
            size=1.25, 
            col='grey5') +
  geom_ribbon(data = lm1_p, aes(ymin = car::logit(conf.low, adjust=0.001), ymax = car::logit(conf.high, adjust=0.001), x = (x)),
              fill = 'grey35', alpha = 0.4, inherit.aes = FALSE) +
  scale_x_continuous(name="Proportion of species referenced by Instagram users",
                     breaks=car::logit(c(0, 0.01, 0.1, 0.5, 0.9, 0.99, 1), adjust=0.001),
                     labels=c(0, 0.01, 0.1, 0.5, 0.9, 0.99, 1)) +
  scale_y_continuous(name="Proportion of species traded in pet stores",
                     breaks=car::logit(c(0, 0.01, 0.1, 0.5, 0.9, 0.99, 1), adjust=0.001),
                     labels=c(0, 0.01, 0.1, 0.5, 0.9, 0.99, 1))
#geom_text(aes(x=Propspecies_IG, y=jitter(Propspecies_IS,1), label=rownames(dfAntsParam_v3.2)), dfAntsParam_v3.2)

fig4d

# genera in stores but not on IG
dfAntsParam[dfAntsParam$Propspecies_IG==0 & dfAntsParam$Propspecies_IS>0,]

# genera on IG  but not in stores
dfAntsParam[dfAntsParam$Propspecies_IG>0 & dfAntsParam$Propspecies_IS==0,]

# svg('fig4d_raw.svg', height = 10, width = 10)
# print(fig4d)
# dev.off()

dfAntsParam_v3["Cryptopone",]
dfAntsParam_v3["Strumigenys",]
dfAntsParam_v3["Lasius",]
dfAntsParam_v3["Wasmannia",]

# Drawing a pretty tree (not in the most elegant way though...)
dfAntsParam_v5 <- dfAntsParam
dfAntsParam_v5$Propspecies_IS <- car::logit(dfAntsParam_v5$Propspecies_IS, adjust=0.001)
dfAntsParam_v5$Propspecies_IG <- car::logit(dfAntsParam_v5$Propspecies_IG, adjust=0.001)
dfAntsParam_v5$Nbspecies_IS <- log(dfAntsParam_v5$Nbspecies_IS+1)
dfAntsParam_v5$Nbspecies_IG <- log(dfAntsParam_v5$Nbspecies_IG+1)
dfAntsParam_v5$NbAllSpecies_log <- log(dfAntsParam_v5$NbAllSpecies+1)
head(dfAntsParam_v5)

variable1 = 'NbAllSpecies_log'
variable2 = 'Propspecies_IS'
variable3 = 'Propspecies_IG'

var1 <- dfAntsParam_v5[,variable1, drop=F]
var1 <- as.matrix(var1)[,1]

var2 <- dfAntsParam_v5[,variable2, drop=F]
var2 <- as.matrix(var2)[,1]

var3 <- dfAntsParam_v5[,variable3, drop=F]
var3 <- as.matrix(var3)[,1]


fit <- phytools::fastAnc(tree_ants, var1, vars=TRUE, CI=TRUE)
td <- data.frame(node = nodeid(tree_ants, names(var1)), NbSpecies = var1)
nd <- data.frame(node = names(fit$ace), NbSpecies = fit$ace)
d <- rbind(td, nd)
d$node <- as.numeric(d$node)
tree <- full_join(tree_ants, d, by = 'node')

range(tree@data$NbSpecies)


fit2 <- phytools::fastAnc(tree_ants, var2, vars=TRUE, CI=TRUE)
td2 <- data.frame(node = nodeid(tree_ants, names(var2)), PropSpecies = var2)
nd2 <- data.frame(node = names(fit2$ace), PropSpecies = fit2$ace)
d2 <- rbind(td2, nd2)
d2$node <- as.numeric(d2$node)

tree@data$PropSpecies <- d2$PropSpecies + abs(min(d2$PropSpecies)) + max(tree@data$NbSpecies) + 2
range(tree@data$PropSpecies)


length(unique(tree@data$PropSpecies)) + length(unique(tree@data$NbSpecies))


fit3 <- phytools::fastAnc(tree_ants, var3, vars=TRUE, CI=TRUE)
td3 <- data.frame(node = nodeid(tree_ants, names(var3)), PropSpecies_IG = var3)
nd3 <- data.frame(node = names(fit3$ace), PropSpecies_IG = fit3$ace)
d3 <- rbind(td3, nd3)
d3$node <- as.numeric(d3$node)

tree@data$PropSpecies_IG <- d3$PropSpecies_IG + abs(min(d3$PropSpecies_IG)) + max(tree@data$PropSpecies) + 2


length(unique(tree@data$NbSpecies)) + length(unique(tree@data$PropSpecies)) + length(unique(tree@data$PropSpecies_IG))

tree@data
range(tree@data$NbSpecies)
range(tree@data$PropSpecies) # 125/413 NAs
range(tree@data$PropSpecies_IG) # 101/413 NAs

range_1 <- round((max(tree@data$NbSpecies) - min(tree@data$NbSpecies))*100)
range_2 <- round((max(tree@data$PropSpecies) - min(tree@data$PropSpecies))*100)
range_3 <- round((max(tree@data$PropSpecies_IG) - min(tree@data$PropSpecies_IG))*100)
gap <- round(2*100)

tree_vtemp <- tree
tree_vtemp@data$PropSpecies_size
tree_vtemp@data$PropSpecies_size <- tree_vtemp@data$PropSpecies
tree_vtemp@data$PropSpecies_IG_size <- tree_vtemp@data$PropSpecies_IG
sort(tree_vtemp@data$PropSpecies)
sort(tree_vtemp@data$PropSpecies_IG)

car::logit(0.5, adjust=0.001) + (abs(min(d2$PropSpecies)) + max(tree@data$NbSpecies) + 2) # value for 50%
boot::inv.logit(16.212 -(abs(min(d2$PropSpecies)) + max(tree@data$NbSpecies) + 2))
boot::inv.logit(17.06 -(abs(min(d2$PropSpecies)) + max(tree@data$NbSpecies) + 2))

car::logit(0.5, adjust=0.001) + (abs(min(d3$PropSpecies_IG)) + max(tree@data$PropSpecies) + 2) # value for 50%
boot::inv.logit(32.026 -(abs(min(d3$PropSpecies_IG)) + max(tree@data$PropSpecies) + 2))
boot::inv.logit(32.87 -(abs(min(d3$PropSpecies_IG)) + max(tree@data$PropSpecies) + 2))


tree_vtemp@data$PropSpecies_size[tree_vtemp@data$PropSpecies_size>16.212] = 17.06 # 16.212 is 0.5 (50%) for IS
tree_vtemp@data$PropSpecies_IG_size[tree_vtemp@data$PropSpecies_IG_size>32.026] = 32.87 # 32.026 is 0.5 (50%) for IG


# build the tree
p1 <- ggtree(tree_vtemp, 
             aes(color=NbSpecies), 
             layout = 'circular', 
             ladderize = TRUE, 
             continuous = F, 
             size=0.75) + #, alpha = 0.4
  xlim(-200, 250) +
  scale_colour_gradientn(colours = c(rev(magma(range_1+120)[1:range_1]), 
                                     rep('white', gap+2), 
                                     rep("#454583ff", range_2), 
                                     rep('white', gap), 
                                     rep("#a4951eff", range_3-6))) +
  scale_fill_gradientn(colours = c(rep('grey60', 5), 
                                   rep("#7b7bc5ff", range_2), 
                                   rep('grey60', gap+5), 
                                   rep("#dfd05bff", range_3))) + # careful: several little adjustments were needed to fit colors correctly
  geom_tiplab(offset = 50, 
              size=3) + 
  theme(legend.position = c(0.02, 0.75), # "none", #
        legend.title = element_text(color = "black", size = 8),
        legend.text = element_text(color = "black", size = 8)) +
  ggtitle(variable1) +
  scale_size_identity()

sizePts <- 0.05
decalage <- 0
alpha1 <- 0.15

p2 <- p1 + 
  geom_tippoint(aes(x=x+1, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1 ) +
  geom_tippoint(aes(x=x+3, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1 ) +
  geom_tippoint(aes(x=x+5, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1 ) +
  geom_tippoint(aes(x=x+7, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1 ) +
  geom_tippoint(aes(x=x+9, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+11, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+13, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+15, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+17, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1 ) +
  geom_tippoint(aes(x=x+19, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1 ) +
  geom_tippoint(aes(x=x+21, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1 ) +
  geom_tippoint(aes(x=x+23, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1 ) +
  geom_tippoint(aes(x=x+25, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+27, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+29, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+31, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+33, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+35, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1 ) +
  geom_tippoint(aes(x=x+37, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+39, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+41, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+43, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+45, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1 ) +
  geom_tippoint(aes(x=x+47, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  ) +
  geom_tippoint(aes(x=x+49, y=y+decalage, size=c(rep(sizePts,413))), shape=20, alpha = alpha1  )

p3 <- p2 + geom_tippoint(aes(x = x+14,
                             y = y+decalage,
                             size = scales::rescale(PropSpecies_size, to=c(0.75, 6.25)),
                             color = PropSpecies, 
                             fill = PropSpecies), 
                         shape = 21 )

p4 <- p3 + geom_tippoint(aes(x = x+36, 
                             y = y+decalage, 
                             size = scales::rescale(PropSpecies_IG_size, to=c(0.75, 6.25)), 
                             color = PropSpecies_IG, 
                             fill = PropSpecies_IG), 
                         shape = 21 )

fig4c <- p4 + geom_treescale(x=-50, offset=1, width=40)
fig4c

# svg('fig4c.svg', height = 10, width = 10)
# print(fig4c)
# dev.off()


# plot for visualizing the sub-families
rangeSpSF <- range(sort(table(GSP_ants_v2$sub.family)))
rangeSpSF_logged <- round(log(rangeSpSF+1)*100)

valuesSF_log <- rev(round(log(sort(table(GSP_ants_v2$sub.family), decreasing=T) + 1)*80)[1:10])

colSF_base <- rainbow(rangeSpSF_logged[2])
colSF <- colSF_base[valuesSF_log[1:10]]

plot((sort(table(GSP_ants_v2$sub.family), decreasing=T)[1:10]), col=colSF, lwd=10)

alpha0 <- 0.5
ext1 <- 10
names.sf <- unique(GSP_ants_v2$sub.family)[c(1,8,9,16,17,3,7,6,13,18)]

fig4b <- ggtree(tree, 
                layout = 'circular', 
                ladderize = TRUE, 
                continuous = F, 
                size=1) +
  xlim(-100, 250) + 
  geom_hilight(node=221, fill=colSF[1], extend=ext1+2, alpha=alpha0) + #1 Myrmicinae 
  geom_hilight(node=217, fill=colSF[6], extend=ext1-1, alpha=alpha0) + #6 Ectatamminae
  geom_hilight(node=294, fill=colSF[2], extend=ext1+2, alpha=alpha0) + #2 Formicinae
  geom_hilight(node=341, fill=colSF[10], extend=ext1-1, alpha=alpha0) + #3 Ponerinae
  geom_hilight(node=359, fill=colSF[8], extend=ext1+2, alpha=alpha0) + #8 Proceratiinae
  geom_hilight(node=362, fill=colSF[5], extend=ext1-1, alpha=alpha0) + #9 Amblyoponae
  geom_hilight(node=369, fill=colSF[9], extend=ext1+2, alpha=alpha0) + #5 Dorylinae
  geom_hilight(node=386, fill=colSF[4], extend=ext1-1, alpha=alpha0) + #4 Dolichoderinae
  geom_hilight(node=411, fill=colSF[3], extend=ext1+2, alpha=alpha0) + #10 Myrmeciinae
  geom_hilight(node=412, fill=colSF[7], extend=ext1-1, alpha=alpha0)  #7 Pseudomyrmicinae

fig4b

# pdf('fig4b_raw.pdf', height = 10, width = 10)
# print(fig4b)
# dev.off()


###########################################################
###########################################################



###########################################################
############# SPECIES level  composition  ##############
###########################################################

head(dfIS)
head(dfIG)
dim(dfIS)
dim(dfIG)

dfSpecies <- data.frame(unique(c(row.names(dfIS), row.names(dfIG))))
colnames(dfSpecies) <- "species"
rownames(dfSpecies) <- dfSpecies$species
dfSpecies$NbSellers_2020 <- 0
dfSpecies$MeanPrice_2020 <- NA
dfSpecies$NbIGUsers_total <- 0
dfSpecies$NbIGPosts_total <- 0
dfSpecies$NbIGPostsByUser <- 0
dfSpecies$NbMedianLikes <- NA
dfSpecies$NbMaxComments <- NA
dfSpecies$inIS <- 0
dfSpecies$inIG <- 0
dfSpecies$sub.family <- NA
dfSpecies$genus <- NA
dfSpecies$NbPosts_2020 <- 0
dfSpecies$NbUsers_2020 <- 0



dim(dfSpecies)
head(dfSpecies)
head(GSP_ants_v2)

for (i in dfSpecies$species){
  dfSpecies[i, "sub.family"] <- GSP_ants_v2[GSP_ants_v2$species== i, "sub.family"]
  dfSpecies[i, "genus"]  <- GSP_ants_v2[GSP_ants_v2$species== i, "genus"]
  if(i %in% row.names(dfIS)){
    dfSpecies[i, "NbSellers_2020"] <- dfIS[i, "NbSellers_2020"]
    dfSpecies[i, "MeanPrice_2020"] <- dfIS[i, "MeanPrice_2020"]
    dfSpecies[i, "inIS"] <- 1
  }
  if(i %in% row.names(dfIG)){
    dfSpecies[i, "NbIGUsers_total"] <- dfIG[i, "NbUsers_total"]
    dfSpecies[i, "NbIGPosts_total"] <- dfIG[i, "NbPosts_total"]
    dfSpecies[i, "NbIGPostsByUser"] <- dfIG[i, "PostsByUser"]
    dfSpecies[i, "NbMedianLikes"] <- dfIG[i, "medianLikes"]
    dfSpecies[i, "NbMaxComments"] <- dfIG[i, "maxComments"]
    dfSpecies[i, "inIG"] <- 1
  }
}

sum(dfSpecies$inIS)
sum(dfSpecies$inIG)

# add invasiveness status
dfSpecies$InvasivenessStatus <- NA
for (species in dfSpecies$species){
  dfSpecies[species, "InvasivenessStatus"] <- as.character(GSP_ants_v2$InvasivenessStatus[GSP_ants_v2$species==species])
}

dfSpecies$InvasivenessStatus <- factor(dfSpecies$InvasivenessStatus, levels=c("Native", "Alien", "Invasive"))



## are online stores and IG identifying the same pet species?
head(GSP_ants_v2)
dim(GSP_ants_v2)
dim(dfSpecies)
TC1 <- table(dfSpecies[,c("inIS", "inIG")])
TC1[1,1] <- dim(GSP_ants_v2)[1] - dim(dfSpecies)[1]
TC1
chisq.test(TC1) # X-squared = 6249.8, df = 1, p-value < 0.00000000000000022

fill_cols  <- alpha(c('#7b7bc5ff', '#dfd05bff', '#d0d0d0ff'), alpha= 0.9)
ants_euler <- list(IS = dfSpecies$species[dfSpecies$inIS==1],
                   IG = dfSpecies$species[dfSpecies$inIG==1],
                   Global = GSP_ants_v2$species)

fig5a <- plot(euler(ants_euler, shape = "ellipse"), quantities = TRUE, fill = fill_cols, lwd=2.5)
fig5a

# pdf("fig5a_raw.pdf", width=8, height=8)
# fig5a
# dev.off()



## species found in online pet stores only
dfISonly <- dfSpecies[dfSpecies$inIS==1,]
dfISonly$inIG <- as.factor(dfISonly$inIG)
head(dfISonly)
dim(dfISonly)

wilcox.test(dfISonly$NbSellers_2020[dfISonly$inIG==0], dfISonly$NbSellers_2020[dfISonly$inIG==1])

# ratio of mean number of sellers for species referenced on instgram vs species not referenced
mean(dfISonly$NbSellers_2020[dfISonly$inIG==1]) / mean(dfISonly$NbSellers_2020[dfISonly$inIG==0])
# ratio of mean number of sellers for invasive species referenced on instagram vs invasive species not referenced
mean(dfISonly$NbSellers_2020[dfISonly$inIG==1& dfISonly$InvasivenessStatus!="Native"]) / mean(dfISonly$NbSellers_2020[dfISonly$inIG==0& dfISonly$InvasivenessStatus!="Native"])


# percent of species detected weighted by number of sellers
sum(dfISonly$NbSellers_2020[dfISonly$inIG==1]) / sum(dfISonly$NbSellers_2020)
# percent of invasive species detected weighted by number of sellers
sum(dfISonly$NbSellers_2020[dfISonly$inIG==1 & dfISonly$InvasivenessStatus!="Native"]) / sum(dfISonly$NbSellers_2020[dfISonly$InvasivenessStatus!="Native"])


#svg('Fig5b_raw.svg', height = 8, width = 6)
dfISonly %>% 
  ggplot(aes(x=inIG, y=NbSellers_2020)) +
  geom_boxplot(width=0.5,lwd=1.5, aes(fill=inIG, col=inIG)) +
  scale_fill_manual(values=alpha(c('#7b7bc5ff', '#42c27fff'), alpha= 0.8)) +
  geom_jitter(width=0.175, height=0.05, size=2.5) +
  scale_color_manual(values=alpha(c('#28285bff', '#1a5235ff'), alpha= 1)) +
  scale_y_continuous(name= "Number of online sellers", trans='log2', breaks=c(1,2,4,8,16,32,64)) +
  scale_x_discrete(name ="", labels=c("Not referenced on IG", "Referenced on IG")) +
  theme_base()
#dev.off()



head(dfSpecies)
# species on instagram only
dfIGonly <- dfSpecies[dfSpecies$inIG==1,]
dfIGonly$inIS <- factor(dfIGonly$inIS, levels=c("1","0"))

wilcox.test(dfIGonly$NbIGUsers_total[dfIGonly$inIS==0], dfIGonly$NbIGUsers_total[dfIGonly$inIS==1])

# ratio of mean number of sellers for species referenced on instgram vs species not referenced
mean(dfIGonly$NbIGUsers_total[dfIGonly$inIS==1]) / mean(dfIGonly$NbIGUsers_total[dfIGonly$inIS==0])


# percent of species detected weighted by number of sellers
sum(dfIGonly$NbIGUsers_total[dfIGonly$inIS==1]) / sum(dfIGonly$NbIGUsers_total)

#svg('Fig5c_raw.svg', height = 8, width = 6)
dfIGonly %>% 
  ggplot(aes(x=inIS, y=NbIGUsers_total )) +
  geom_boxplot(width=0.5,lwd=1.5, aes(fill=inIS, col=inIS)) +
  scale_fill_manual(values=alpha(c('#42c27fff', '#dfd05bff'), alpha= 0.8)) +
  geom_jitter(width=0.175, height=0.05, size=2.5) +
  scale_color_manual(values=alpha(c('#1a5235ff', '#776c17ff'), alpha= 1)) +
  scale_y_continuous(name= "Number of users referencing the species as a pet on Instagram", trans='log2', breaks=c(1,2,4,8,16,32,64,128,256,512)) +
  scale_x_discrete(name ="", labels=c("Species traded", "Species not traded")) +
  theme_base()
#dev.off()

#



########## Can Instagram popularity metrics predict the number of sellers per species? ##########
dftemp1 <- dfSpecies
head(dftemp1)
dftemp1$NbIGUsers_log <- log(dftemp1$NbIGUsers_total+1)
dftemp1$NbIGPosts_log <- log(dftemp1$NbIGPosts_total+1)
dftemp1$NbIGPostsByUser_log <- log(dftemp1$NbIGPostsByUser+1)
dftemp1$NbLikes_log <- log(dftemp1$NbMedianLikes +1)
dftemp1$NbComments_log <- log(dftemp1$NbMaxComments  +1)
dftemp1$MeanPrice_log <- log(dftemp1$MeanPrice+1)
dftemp1$NbSellers_log <- log(dftemp1$NbSellers+1)
dftemp1$sub.family <- as.factor(dftemp1$sub.family)
hist(dftemp1$NbSellers_log)
dftemp1$InvasivenessStatus <- factor(dftemp1$InvasivenessStatus, levels=c("Native","Alien","Invasive"))
#dftemp1$NBLikes[is.na(dftemp1$NbLikes)] <- 0
dim(dftemp1)
head(dftemp1)

dftemp1$group <- NA
for (i in 1:dim(dftemp1)[1]){
  if (dftemp1$inIS[i]==1 & dftemp1$inIG[i]==1){dftemp1$group[i] <-"IG and sellers"
  } else if (dftemp1$inIS[i]==1 & dftemp1$inIG[i]==0){dftemp1$group[i] <-"Sellers only"
  } else{dftemp1$group[i] <-"IG only"}
}
dftemp1$group <- as.factor(dftemp1$group)


hist(dftemp1$NbSellers_2020[dftemp1$inIG==1], nclass=100) # clearly zero-inflated and  overdispersed
table(dftemp1$NbSellers_2020[dftemp1$inIG==1])


reg1 <- glmmTMB(NbSellers_2020 ~  1 +
                  NbIGUsers_log +
                  NbIGPostsByUser_log +
                  NbLikes_log +
                  (1|sub.family)
                ,
                ziformula = ~ 1 +
                  NbIGUsers_log +
                  NbIGPostsByUser_log +
                  NbLikes_log +
                  (1|sub.family)
                ,
                family=nbinom2,
                data=dftemp1[dftemp1$inIG==1,])

summary(reg1)
r2_zeroinflated(reg1, method="correlation")
plot(simulateResiduals(reg1))

ef_reg1 <- ggpredict(reg1, c("NbIGUsers_log"), back.transform=TRUE, type="fe.zi") # , condition = list(NbAllSpecies_log =2)
plot(ef_reg1, line.size=1.75, dot.size=4, dodge=0.4) 


fig5d <- ggplot(data=dftemp1, aes(x=(NbIGUsers_log), y=NbSellers_log)) +
  theme_clean() +
  theme(plot.margin = unit(c(2, 2, 1, 1), "cm"),
        axis.title.x = element_text(size = 15, vjust = -2),
        axis.title.y = element_text(size = 15, vjust = 2),
        axis.text.x = element_text(size=14),
        axis.text.y = element_text(size=14)) +
  geom_jitter(data= dftemp1, 
              aes(fill=factor(group), colour=factor(group), size=NbIGPostsByUser),
              width=0.05,
              height = 0.05,
              stroke=1.25,
              shape=21) +
  scale_size_continuous(range = c(1.5, 10)) +
  geom_line(data=ef_reg1, 
            aes(x=(x), y=log(predicted+1)), 
            size=1.25, 
            col='grey55') +
  geom_ribbon(data = ef_reg1, aes(ymin = log(conf.low+1), ymax = log(conf.high+1), x = (x)),
              fill = 'grey35', alpha = 0.3, inherit.aes = FALSE) +
  scale_y_continuous(name="Number of sellers",
                     breaks=log(c(0, 1, 2, 5, 10, 20, 50, 100, 200)+1),
                     labels=c(0, 1, 2, 5, 10, 20, 50, 100, 200)) +
  scale_x_continuous(name="Number of Instagram users",
                     breaks=log(c(0, 1, 2, 5, 10, 20, 50, 100, 200, 500)+1),
                     labels=c(0, 1, 2, 5, 10, 20, 50, 100, 200, 500)) +
  scale_fill_manual(values=alpha(c('#42c27fff', '#dfd05bff', '#7b7bc5ff'), alpha= 0.4)) +
  scale_colour_manual(values=alpha(c('#42c27fff', '#dfd05bff', '#7b7bc5ff'), alpha= 0.8)) +
  theme(legend.title = element_text(size=8, color = "black", face="bold"),
        legend.justification=c(0,1), 
        legend.position=c(0.05, 0.95),
        legend.background = element_blank(),
        legend.key = element_blank())
fig5d



# pdf('Fig5_v2.pdf', height = 8, width = 8)
# fig5d
# dev.off()




## Comparing noninvasive and invasive species

## are online stores and IG identifying the same pet invasive species?

head(dfSpecies)
dim(dfSpecies)

ants_euler2 <- list(IS = dfSpecies$species[dfSpecies$inIS==1],
                    IG = dfSpecies$species[dfSpecies$inIG==1],
                    Invasive = GSP_ants_v2$species[GSP_ants_v2$InvasivenessStatus !="Native"])

fill_cols2  <- alpha(c('#7b7bc5ff', '#dfd05bff', 'indianred'), alpha= 0.9)

fig6a <- plot(euler(ants_euler2, shape = "ellipse"), quantities = TRUE, fill = fill_cols2, lwd=2.5)
fig6a


TC2 <- table(dfSpecies[dfSpecies$InvasivenessStatus!="Native",c("inIS", "inIG")])
TC2[1,1] <- dim(GSP_ants_v2[GSP_ants_v2$InvasivenessStatus !="Native",])[1] - dim(dfSpecies[dfSpecies$InvasivenessStatus!="Native",])[1]
TC2
chisq.test(TC2) # X-squared = 118.95, df = 1, p-value < 2.2e-16


# is the proportion of species detected by instagram higher for invasive species than for all species?
prop.test(c(59,439), c(68,631)) # X-squared = 8.0374, df = 1, p-value = 0.004582


# ratio of mean number of sellers for invasive species referenced on instagram vs invasive species not referenced
mean(dfIGonly$NbIGUsers_total[dfIGonly$inIS==1& dfIGonly$InvasivenessStatus!="Native"]) / mean(dfIGonly$NbIGUsers_total[dfIGonly$inIS==0 & dfIGonly$InvasivenessStatus!="Native"])
# percent of invasive species detected weighted by number of sellers
sum(dfIGonly$NbIGUsers_total[dfIGonly$inIS==1 & dfIGonly$InvasivenessStatus!="Native"]) / sum(dfIGonly$NbIGUsers_total[dfIGonly$InvasivenessStatus!="Native"])



table(dfSpecies$InvasivenessStatus)
dfSpecies$InvasivenessStatus.2 <- "Non-invasive"
dfSpecies$InvasivenessStatus.2[dfSpecies$InvasivenessStatus!="Native"] = "Invasive"
dfSpecies$InvasivenessStatus.2 <- factor(dfSpecies$InvasivenessStatus.2, levels=c("Non-invasive","Invasive"))


# Comparing number of sellers between native and invasive species
df_compInstagram <- dfSpecies[dfSpecies$inIG==1 & dfSpecies$NbIGUsers_total>1,] # 
df_compInstagram$sub.family <- factor(df_compInstagram$sub.family)
dim(df_compInstagram)

df_compInstagram$NbIGUsers_total_log <- log(df_compInstagram$NbIGUsers_total+1)
df_compInstagram$NbIGPosts_total_log <- log(df_compInstagram$NbIGPosts_total+1)


# median users
median(df_compInstagram$NbIGUsers_total[df_compInstagram$InvasivenessStatus.2=="Invasive"])
median(df_compInstagram$NbIGUsers_total[df_compInstagram$InvasivenessStatus.2!="Invasive"])

# mean users
mUsers_INVA <- mean(df_compInstagram$NbIGUsers_total[df_compInstagram$InvasivenessStatus.2=="Invasive"])
mUsers_NAT <- mean(df_compInstagram$NbIGUsers_total[df_compInstagram$InvasivenessStatus.2!="Invasive"])
mUsers_INVA/mUsers_NAT

# se users
sd(df_compInstagram$NbIGUsers_total[df_compInstagram$InvasivenessStatus.2=="Invasive"])/sqrt(dim(df_compInstagram)[1])
sd(df_compInstagram$NbIGUsers_total[df_compInstagram$InvasivenessStatus.2!="Invasive"])/sqrt(dim(df_compInstagram)[1])


lm_inva_users <- glmmTMB(NbIGUsers_total_log ~ 1
                         + InvasivenessStatus.2
                         + (1|sub.family),
                         family=gaussian,
                         data=df_compInstagram)
summary(lm_inva_users)
car::Anova(lm_inva_users)
plot(simulateResiduals(lm_inva_users))

wilcox.test( df_compInstagram$NbIGUsers_total_log[df_compInstagram$NbIGUsers_total>1 & df_compInstagram$InvasivenessStatus.2=="Invasive"], 
             df_compInstagram$NbIGUsers_total_log[df_compInstagram$NbIGUsers_total>1 & df_compInstagram$InvasivenessStatus.2!="Invasive"])

wilcox.test( df_compInstagram$NbIGUsers_total_log[df_compInstagram$InvasivenessStatus.2=="Invasive"], 
             df_compInstagram$NbIGUsers_total_log[df_compInstagram$InvasivenessStatus.2!="Invasive"])

# plot effects
ef_lm_inva_users <- ggpredict(lm_inva_users, c("InvasivenessStatus.2"), back.transform=TRUE, type="fe") # , condition = list(NbAllSpecies_log =2)
plot(ef_lm_inva_users, line.size=1.75, dot.size=4, dodge=0.4) 

fig_inva_instagram_users <- ggplot() +
  theme_bw() +
  geom_jitter(data=df_compInstagram[df_compInstagram$NbIGUsers_total>1,], 
              aes(x=InvasivenessStatus.2, 
                  y=NbIGUsers_total_log,
                  fill=InvasivenessStatus.2),
              alpha=0.25,
              size=1.5,
              width=0.2,
              height = 0.05,
              stroke=0.25,
              shape=21) +
  scale_fill_manual(values=c("grey85","indianred")) +
  scale_y_continuous(name="Number of Instagram users",
                     position = "right",
                     breaks= log(c(2,5,10,20,50,100,200,500)+1),
                     labels=c(2,5,10,20,50,100,200,500)) +
  scale_x_discrete(labels= c("Non\ninvasive","Invasive")) +
  geom_segment(data=ef_lm_inva_users,
               aes(x=factor(x),
                   xend=factor(x),
                   y=conf.low,
                   yend=conf.high),
               size=1.5) +
  geom_point(data=ef_lm_inva_users,
             aes(x=factor(x),
                 y=predicted,
                 fill=factor(x)),
             size=3,
             shape=22,
             stroke=1) +
  theme(plot.margin = unit(c(0.1, 0.1, 0.1, 0.1), "cm"),
        axis.title.x = element_blank(),
        axis.title.y = element_text(size = 10),
        axis.text.x = element_text(size=8),
        axis.text.y = element_text(size=8),
        legend.justification=c(0,1), 
        legend.position="none",
        legend.background = element_blank(),
        legend.key = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.y = element_line(size=.1, linetype=2, color="grey85" ),
        panel.grid.major.y = element_line(size=.2, linetype=2, color="grey85" ),
        panel.background = element_rect(fill="#fbf9eaff")) +
  annotate("text", x = 1.5, y = 0.999*max(df_compInstagram$NbIGUsers_total_log), label = "***", size=5, fontface = "bold") +
  geom_segment(aes(x=1,
                   xend=2,
                   y=0.999*max(df_compInstagram$NbIGUsers_total_log) - 0.1,
                   yend=0.999*max(df_compInstagram$NbIGUsers_total_log) - 0.1),
               size=1)

fig_inva_instagram_users


df_compInstagram[df_compInstagram$NbIGUsers_total>100, c("species","InvasivenessStatus","NbIGUsers_total", "NbIGPosts_total")]

#


# Comparing number of sellers between native and invasive species

df_compSellers <- dfSpecies[dfSpecies$NbSellers_2020>0,]
df_compSellers$sub.family <- factor(df_compSellers$sub.family)
dim(df_compSellers)

# median
median(df_compSellers$NbSellers_2020[df_compSellers$InvasivenessStatus.2=="Invasive"])
median(df_compSellers$NbSellers_2020[df_compSellers$InvasivenessStatus.2!="Invasive"])

# mean
mSellers_INVA <- mean(df_compSellers$NbSellers_2020[df_compSellers$InvasivenessStatus.2=="Invasive"])
mSellers_NAT <- mean(df_compSellers$NbSellers_2020[df_compSellers$InvasivenessStatus.2!="Invasive"])
mSellers_INVA/mSellers_NAT


# se
sd(df_compSellers$NbSellers_2020[df_compSellers$InvasivenessStatus.2=="Invasive"])/sqrt(dim(df_compSellers)[1])
sd(df_compSellers$NbSellers_2020[df_compSellers$InvasivenessStatus.2!="Invasive"])/sqrt(dim(df_compSellers)[1])


lm_inva.sellers <- glmmTMB(NbSellers_2020 ~ 1
                           + InvasivenessStatus.2
                           + (1|sub.family),
                           family=truncated_nbinom2, #truncated_nbinom1
                           data=df_compSellers) # [sample(1:628, 100),]
summary(lm_inva.sellers)
plot(simulateResiduals(lm_inva.sellers))

# library(emmeans)
# contrastTest2 <- emmeans(lm_inva.sellers, specs=pairwise~InvasivenessStatus, type="response", adjust="tukey")
# contrastTest2 

wilcox.test(df_compSellers$NbSellers_2020[df_compSellers$InvasivenessStatus.2=="Invasive"], 
            df_compSellers$NbSellers_2020[df_compSellers$InvasivenessStatus.2!="Invasive"])


ef_lm_inva_sellers <- ggpredict(lm_inva.sellers, c("InvasivenessStatus.2"), back.transform=TRUE, type="fe") # , condition = list(NbAllSpecies_log =2)
plot(ef_lm_inva_sellers, line.size=1.75, dot.size=4, dodge=0.4) 

fig_inva_sellers <- ggplot() +
  theme_bw() +
  geom_jitter(data=df_compSellers, 
              aes(x=InvasivenessStatus.2, 
                  y=NbSellers_2020,
                  fill=InvasivenessStatus.2),
              alpha=0.25,
              size=1.5,
              width=0.2,
              height = 0.05,
              stroke=0.25,
              shape=21) +
  scale_fill_manual(values=c("grey85","indianred")) +
  scale_y_continuous(name="Number of sellers",
                     breaks= c(1,2,5,10,20,50,100),
                     trans='log') +
  scale_x_discrete(labels= c("Non\ninvasive","Invasive")) +
  geom_segment(data=ef_lm_inva_sellers,
               aes(x=factor(x),
                   xend=factor(x),
                   y=conf.low,
                   yend=conf.high),
               size=1.5) +
  geom_point(data=ef_lm_inva_sellers,
             aes(x=factor(x),
                 y=predicted,
                 fill=factor(x)),
             size=3,
             shape=22,
             stroke=1) +
  theme(plot.margin = unit(c(0.1, 0.1, 0.1, 0.1), "cm"),
        axis.title.x = element_blank(),
        axis.title.y = element_text(size = 10),
        #axis.text.x = element_blank(),
        axis.text.y = element_text(size=8),
        legend.justification=c(0,1), 
        legend.position="none",
        legend.background = element_blank(),
        legend.key = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.y = element_line(size=.1, linetype=2, color="grey85" ),
        panel.grid.major.y = element_line(size=.2, linetype=2, color="grey85" ),
        panel.background = element_rect(fill="#ededf7ff")) +
  annotate("text", x = 1.5, y = 0.95*max(df_compSellers$NbSellers_2020), label = "**", size=5, fontface = "bold") +
  geom_segment(aes(x=1,
                   xend=2,
                   y=0.95*max(df_compSellers$NbSellers_2020) - 5,
                   yend=0.95*max(df_compSellers$NbSellers_2020) - 5),
               size=1)

fig_inva_sellers

#####################################################################


# Figure with the two panels
fig6b <- fig_inva_sellers  +  fig_inva_instagram_users + 
  plot_layout(ncol = 2, nrow = 1, widths = c(4,4), heights = 4)

fig6b

# ggsave("fig6b_raw.pdf", fig6b, width=3, height=5)
# ggsave("fig6b_raw.png", fig6b, width=3, height=5)


#######################################################################################################


